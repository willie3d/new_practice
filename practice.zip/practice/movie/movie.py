import webapp2
from google.appengine.ext import ndb


class Movie(ndb.model):

    title = ndb.StringProperty(required=True)
    media_type = ndb.StringProperty(required=True, default="Movie")
    runtime = ndb.IntegerProperty(required=False)
    rating = ndb.FloatProperty(required=False)

    def autoplay(self):
        if (self.runtime<=120) and (self.rating>=9.0):
            return "Up Next: " + self.title
        else:
            return "Search for More Movies"

    # def description(self):
    #     return ("%s appeared in %s, is %s long and rated %s. " % (self.title, str(self.year), str(self.runtime_mins), str(self.rating)))

movie1 = Movie("Inception", 140, 10.0, 2010)
movie2 = Movie("Interstellar", 169, 8.7, 2014)
movie3 = Movie("Avengers", 182, 7.5, 2011)

class MainPage(webapp2.RequestHandler):
    def get(self):  # for a get request
        self.response.headers['Content-Type'] = 'text/plain'
        self.response.write("<h1>He</h1>")
        self.response.write(movie1.description())
        self.response.write(movie2.description())
        self.response.write(movie3.description())

app = webapp2.WSGIApplication([
    ('/', MainPage),
], debug=True)
