import webapp2
import jinja2
import os


the_jinja_env = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True)


# the handler section
class MainPage(webapp2.RequestHandler):
    def get(self):  # for a get request
        self.response.write("<h1>He</h1>")


class HomePage(webapp2.RequestHandler):
    def get(self):
        self.response.write("<h1>Hoooo</h1>")  # the response


class About(webapp2.RequestHandler):
    def get(self):
        self.response.write("<h1>AHHHHHHH ROBOTS</h1>")  # the response


class EnterInfoHandler(webapp2.RequestHandler):
    def get(self):  # for a get request
        welcome_template = the_jinja_env.get_template('templates/welcome.html')
        self.response.write(welcome_template.render())

    def post(self):  # for a get request
        first_line=self.request.get("user-first-ln")
        second_line=self.request.get("user-second-ln")
        result_template = the_jinja_env.get_template('templates/memeresult.html')
        result_template_dict = {
            "line1": first_line,
            "line2": second_line,
            "img_url": "https://upload.wikimedia.org/wikipedia/commons/f/ff/Deep_in_thought.jpg"
        }
        self.response.write(result_template.render(result_template_dict))


class ShowMemeHandler(webapp2.RequestHandler):
    def get(self):
        results_template = the_jinja_env.get_template('templates/memeresult.html')
        self.response.write(results_template.render())  # the response


class MoreMemeHandler(webapp2.RequestHandler):
    def get(self):
        results_template = the_jinja_env.get_template('templates/more.html')
        the_variable_dict = {
            "line1": "If Cinderella's shoe was a perfect fit",
            "line2": "Why did it fall off?",
            "img_url": "https://upload.wikimedia.org/wikipedia/commons/f/ff/Deep_in_thought.jpg"
        }
        self.response.write(results_template.render(the_variable_dict))


app = webapp2.WSGIApplication([
    ('/', MainPage),
    ('/home', HomePage),
    ('/about-us', About),
    ('/memeresult', EnterInfoHandler),
    ('/welcome', ShowMemeHandler),
    ('/more', MoreMemeHandler),
], debug=True)
