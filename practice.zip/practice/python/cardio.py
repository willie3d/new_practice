# def count_spaces(s):
#     return s.count(" ")
# print(count_spaces("hello world!"))  # => 1
# print(count_spaces("wow wow wow "))  # => 3
#
# def longestWord(sentence):
#     longest = 0
#     word = ''
#     for i in sentence.split():
#         if len(i) > longest:
#             word = i
#             longest = len(i)
#     return word
# print longestWord("qwqwwq qwewqeqwe qweqw qweqweqw eqweqwe")
#
# #def roll_dice(dice_int):
# num_of_dice = raw_input("How many dice? ")
#
# def roll_dice(num_of_dice):
#     added_dice= 0
#     x=1
#     while x <= (int(num_of_dice)):
#         added_dice = added_dice+(random.randint(1,6))
#         x=x+1
#         print added_dice
#     return added_dice
# print roll_dice(num_of_dice)

def sum_to_n(num):
    total=0
    for i in range(0,num+1):
        total=total+i
    return total
print sum_to_n(12)
print sum_to_n(5)
print sum_to_n(2)
students = ["Alice","Bob","Charels"]
print students[0]
def story(students):
    message=""
    for index in range(0, len(students)-1):
        message=message+ students[index] + ", "
    message=((message+ "and " + students[-1]) +
        " are characters in security stories")
    print message
story(students)
