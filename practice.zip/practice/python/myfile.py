import random
def greetAgent(first_name, last_name):
    print("%s. %s %s." % (last_name, first_name, last_name))

def count_spaces(s):
    return s.count(" ")
print(count_spaces("hello world!"))
print(count_spaces("wow wow wow "))



# print("--------------------------------------------------------")
# print ("hello World!")
# print ("goodbye World!")
# name = raw_input("what is your name?")
# print ("HI "+ name)
# print(100 + 10)
# print(-100 - 10)
# print(5 * 10)
# print(5 ** 2)
# print(25 / 5)
# print(10 / 4)
# print(10 % 4)
# print(21 / 5)
# print(21.0 / 5)
# print(21 / 5.0)
# print(3 + 4 * 5)
# print("--------------------------------------------------------")
# name_first = raw_input("what is your first name?")
# name_last = raw_input("what is your last name?")
# print ("hello "+name_first+" "+name_last)
# word = raw_input("what is your word?")
# print((word+" ") * 5)
# word2 = raw_input("what is your second word?")
# wordlen = len(word2)
# x=1
# while x <= wordlen:
#     print (word2)
#     x=x+1
# print("--------------------------------------------------------")
# print("--------------------------------------------------------")
# int1 = raw_input("Enter number #1: ")
# if not int1.isdigit():
#     print "Not an interger"
#     quit()
# int2 = raw_input("Enter number #2: ")
# int_a= (int(int1) + int(int2))
# print ("The answer is "+str(int_a))
# print("--------------------------------------------------------")
# print("--------------------------------------------------------")
# num_of_items = raw_input("Number of items: ")
# the_word = raw_input("Word: ")
# if int(num_of_items)>1:
#     print (num_of_items+" "+the_word+"s")
# print("--------------------------------------------------------")
# print("--------------------------------------------------------")
# string = "hello there"
# for letter in string:
#     print(letter.upper())
# x = 1
# while x <= 5:
#     print(x)
#     x = x + 1
states = {
  "NY": "New York",
  "CA": "California",
  "TX": "Texas"
}


user2 = {
  "name": "Hat Kid",
  "username": "SmugHat64",
  "animal": "human",
  "favorite hobbies": ["making friends", "cooking", "riding the train"],
  "credentials": {
    "space license": True,
    "chef license": True,
    "mafia license": False
  },
  "age": 10
}


user1 = {
  "name": "Willie",
  "username": "willdoy3le",
  "pet": "none",
  "favorite hobbies": ["making friends", "robotics", "winning"],
  "credentials": {
    "driver license": True,
    "CPR license": True,
    "Library license": True
  },
  "age": 17
}
class Pet(object):
    """docstring for Pet."""

    def __init__(self, name, age, animal, isHungry, mood):
        self.name = name
        self.age = age
        self.animal = animal
        self.isHungry = isHungry
        self.mood = mood
    def __str__(self):
        description="%s is a %s %s"(self.name, self.mood, self.animal)
    def __str__(self):
        if self.isHungry:
        description="%s is a %s %s"(self.name, self.mood, self.animal)


pet1=Pet("Fido",3, "dog", True, "happy")
pet2=Pet("Ecash",6, "dog", False, "angry")
pet3=Pet("Oldie",12, "deer", True,"calm")
print pet1.vars
print pet2
print pet3
