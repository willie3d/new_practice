console.log('hello!!');
console.log("Hello again!");
let name = ("Link");

if(name === "Jamens Brothsworth") {
  console.log("It's " + name + "! How ya been?");
} else if (name === "Link" || name === "Zelda"){
  console.log(name + "! Its nice to see you! ... You shall die.");
} else if (name === "") {
  console.log("You have no name");
} else {
  console.log("Hello, " + name + ". How are you doing today");
}
const firstFunction = () => {
  console.log('My first function!');
}
