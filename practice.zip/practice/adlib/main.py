# import webapp2
# import jinja2
# import os
#
# the_jinja_env = jinja2.Environment(
#     loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
#     extensions=['jinja2.ext.autoescape'],
#     autoescape=True)
#
# story_dict_1 = {
#     'name': 'James',
#     'adjective': 'hard',
#     'noun': 'worker',
#     'verb': 'play',
# }
# story_dict_2 = {
#     'name': 'Willie',
#     'adjective': 'cool',
#     'noun': 'person',
#     'verb': 'win',
#
# }
#
#
# class OnePage(webapp2.RequestHandler):
#     def get(self):  # for a get request
#         story_template = the_jinja_env.get_template('templates/story.html')
#         self.response.write(story_template.render(
#             story_dict_2))  # the response
#
#
# class MainPage(webapp2.RequestHandler):
#     def get(self):  # for a get request
#         story_template = the_jinja_env.get_template('templates/story.html')
#         self.response.write(story_template.render(
#             story_dict_1))  # the response
#
#
# # the app configuration section
# app = webapp2.WSGIApplication([
#     ('/', MainPage),
#     ('/1', OnePage),
#
#
# ], debug=True)
import logging
import webapp2
import jinja2
import os

the_jinja_env = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True)

story_dict = {'name': 'James', 'noun': 'worker', 'verb': 'play', }


class MainPage(webapp2.RequestHandler):
    def get(self):  # for a get request
        story_template = the_jinja_env.get_template('templates/story.html')
        self.response.write(story_template.render(story_dict))  # the response

    def post(self):
        #logging.debug('This is a debug message')
        entered_name = self.request.get('entered_name')
        noun = self.request.get('noun')
        verb = self.request.get('verb')
        story_dict['name'] = entered_name
        story_dict['noun'] = noun
        story_dict["verb"] = verb
        logging.debug('This is a debug message2')
        result_template = the_jinja_env.get_template('templates/storyfinal.html')
        self.response.write(result_template.render(story_dict))  # the response
        # self.response.write("Hello World")


# the app configuration section
app = webapp2.WSGIApplication([
    ('/', MainPage),
    ('/result', MainPage),

], debug=True)
