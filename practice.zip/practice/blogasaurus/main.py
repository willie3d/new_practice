import webapp2
import jinja2
import os
import datetime
from google.appengine.ext import ndb

the_jinja_env = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True)

class Post(ndb.Model):
    name =  ndb.IntegerProperty(required=True)
    post =  ndb.StringProperty(required=True)

class HomePage(webapp2.RequestHandler):
    def get(self):  # for a get request
        story_template = the_jinja_env.get_template('templates/home.html')
        self.response.write(story_template.render())  # the response
class AboutPage(webapp2.RequestHandler):
    def get(self):  # for a get request
        story_template = the_jinja_env.get_template('templates/about.html')
        self.response.write(story_template.render())  # the response

class ExtraPage(webapp2.RequestHandler):
    def get(self):  # for a get request
        story_template = the_jinja_env.get_template('templates/extra.html')
        self.response.write(story_template.render())  # the response
class ChatPage(webapp2.RequestHandler):
    def get(self):  # for a get request
        story_template = the_jinja_env.get_template('templates/chat.html')
        self.response.write(story_template.render())
class ChatPage2(webapp2.RequestHandler):
    def get(self):  # for a get request
        story_template = the_jinja_env.get_template('templates/chat_confirm.html')
        self.response.write(story_template.render())
class MatrixPage(webapp2.RequestHandler):
    def get(self):  # for a get request
        story_template = the_jinja_env.get_template('templates/matrix.html')
        self.response.write(story_template.render())

# the app configuration section
app = webapp2.WSGIApplication([
    ('/', HomePage),
    ('/home', HomePage),
    ('/about', AboutPage),
    ('/extra', ExtraPage),
    ('/chat', ChatPage),
    ('/chat2', ChatPage),
    ('/matrix', MatrixPage),

], debug=True)
